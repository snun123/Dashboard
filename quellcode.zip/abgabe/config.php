<?php


$host = "localhost";
$user = "root";
$dbpw = "";
$db = "dashboarddb";


?>